package mainPackage;

public enum TaskType {
    SEND, GET
}
