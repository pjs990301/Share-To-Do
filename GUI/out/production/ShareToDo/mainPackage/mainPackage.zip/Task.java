package mainPackage;

public enum Task {
    ROOM_LOGIN, ROOM_ESTABLISH, CHANGE_ROOM_INFO
}
