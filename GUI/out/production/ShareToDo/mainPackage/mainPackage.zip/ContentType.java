package mainPackage;

public enum ContentType {
    ROOM_ID, ROOM_PASSWORD, USER_NAME, ROOM_NAME
}
