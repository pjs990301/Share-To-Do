package mainPackage;

import java.net.*;
import java.io.*;


public class ClientSocket {
    private Socket clientSocket = null;
    private BufferedReader fromServer = null;
    private DataOutputStream toServer = null;

    private String ip = "127.0.0.1";
    private int port = 1254;

    public ClientSocket()
    {
        try{
            clientSocket = new Socket(ip, port);
            toServer = new DataOutputStream(clientSocket.getOutputStream());
            fromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        } catch (Exception e) {
            System.out.println("[Error] " + e.getMessage());
        }
    }

    public void CloseConnection()
    {
        try{
            clientSocket.close();
        } catch (Exception e) {
            System.out.println("[Error] " + e.getMessage());
        }
    }

    public void SendToServer(Message message)
    {
        String sendMsg, rcvMsg;
        try{
            sendMsg = message.TranslateToString();
            toServer.writeBytes(sendMsg + '\n');

            rcvMsg = fromServer.readLine();

        }catch (Exception e) {
            System.out.println("[Error] " + e.getMessage());
        }
    }
}
