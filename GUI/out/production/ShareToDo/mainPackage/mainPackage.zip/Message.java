package mainPackage;

import java.util.ArrayList;

//enum TaskType {SEND, GET}
//enum Task {ROOM_LOGIN, ROOM_ESTABLISH, CHANGE_ROOM_INFO}
//enum ContentType {ROOM_ID, ROOM_PASSWORD, USER_NAME, ROOM_NAME, }

public class Message {
    private TaskType taskType;
    private Task task;
    private ArrayList<ContentType> contentType = new ArrayList<>();
    private ArrayList<String> content = new ArrayList<>();

    private String[] keywords = {"TASK_TYPE", "TASK", "CONTENT_TYPE", "CONTENT"};
    private String divider = "/";
    private String colon = ":";

    public Message(TaskType taskType, Task task)
    {
        this.taskType = taskType;
        this.task = task;
    }

    public Message(String msg)
    {
        TranslateFromString(msg);
    }

    public void AddContent(ContentType newContentType, String newContent)
    {
        contentType.add(newContentType);
        content.add(newContent);
    }

    public String TranslateToString()
    {
        String msg = "";

        msg += keywords[0] + colon + taskType.toString() + divider;
        msg += keywords[1] + colon + task.toString() + divider;

        for(int i = 0; i < contentType.size(); i++)
        {
            msg += keywords[2] + colon + contentType.get(i).toString() + divider;
            msg += keywords[3] + colon + content.get(i) + divider;
        }

        return msg;
    }

    public void TranslateFromString(String msg)
    {
        taskType = TaskType.valueOf(GetContent(msg, keywords[0]));
        msg = ClearPriorMessage(msg);
        task = Task.valueOf(GetContent(msg, keywords[1]));
        msg = ClearPriorMessage(msg);

        while(msg.indexOf(divider) != msg.length() - 1)
        {
            contentType.add(ContentType.valueOf(GetContent(msg, keywords[2])));
            msg = ClearPriorMessage(msg);
            content.add(GetContent(msg, keywords[3]));
            msg = ClearPriorMessage(msg);
        }
    }

    private String GetContent(String msg, String keyword)
    {
        String content = msg.substring(msg.indexOf(keyword) + keyword.length() + 1, msg.indexOf(divider));
        return content;
    }

    private String ClearPriorMessage(String msg)
    {
        return msg.substring(msg.indexOf(divider) + 1);
    }
}
